#!/usr/bin/env python3
"""
retrieve_items_action_server.py — Scaffold for the RetrieveItems action server.

TODO(STUDENTS): Implement the action server logic in this file.
You will need to:
  1. Define any service types you need and import them below.
  2. Create service clients in __init__ for each hardware service you call.
  3. Fill in goal_callback, cancel_callback, and execute_callback.
"""


import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from rclpy.action import CancelResponse, GoalResponse
from rclpy.executors import MultiThreadedExecutor

from xarm_pickup_interfaces.action import RetrieveItems
from xarm_pickup_interfaces.srv import (
    MoveToCell,
    MoveGraspedToDeposit,
    GetGripperPosition,
    SetGripper,
    ServoOff,
)

class RetrieveItemsActionServer(Node):
    """Action server that executes a RetrieveItems goal."""

    def __init__(self):
        super().__init__('retrieve_items_action_server')

        # Create service clients for the hardware services we will call.
        self.move_to_cell_client = self.create_client(MoveToCell, 'Move_To_Cell')
        self.move_grasped_to_deposit_client = self.create_client(MoveGraspedToDeposit, 'Move_Grasped_To_Deposit')
        self.get_gripper_pos_client = self.create_client(GetGripperPosition, 'GetGripperPosition')
        self.set_gripper_client = self.create_client(SetGripper, 'SetGripper')
        self.servo_off_client = self.create_client(ServoOff, "ServoOff")

        # Wait for the service servers to become available.
        self.get_logger().info("Waiting for service servers...")
        self.move_to_cell_client.wait_for_service()
        self.move_grasped_to_deposit_client.wait_for_service()
        self.set_gripper_client.wait_for_service()
        self.get_gripper_pos_client.wait_for_service()
        self.servo_off_client.wait_for_service()
        self.get_logger().info("Hardware services connected.")

        self._action_server = ActionServer(
            self,
            RetrieveItems,
            'retrieve_items',
            goal_callback=self.goal_callback,
            cancel_callback=self.cancel_callback,
            execute_callback=self.execute_callback,
        )

        self.get_logger().info('retrieve_items_action_server is running.')

    def goal_callback(self, goal_request):
        """Accept or reject an incoming goal request.

        TODO(STUDENTS): Add any validation logic here (e.g. reject if num_items is out of range).
        Return GoalResponse.REJECT to refuse a goal before execution begins.
        """
        num = goal_request.num_items
        if 1 <= num <= 9:
            self.get_logger().info(f'Received goal: num_items={num}')
            return GoalResponse.ACCEPT
        else:
            self.get_logger().warn(f'Goal rejected: num_items={num} out of range')
            return GoalResponse.REJECT

    def cancel_callback(self, goal_handle):
        """Accept or reject a cancel request for an active goal."""

        feedback_msg = RetrieveItems.Feedback()
        self.get_logger().info('Received cancel request.')
        feedback_msg.state = 'Cancelled'
        goal_handle.publish_feedback(feedback_msg)

        return CancelResponse.ACCEPT

    async def execute_callback(self, goal_handle):
        """Execute the RetrieveItems goal.

        This method runs in a separate thread via the MultiThreadedExecutor.
        It publishes feedback and returns a Result when the goal finishes.
        """

        self.get_logger().info('Executing goal...')

        num_items = goal_handle.request.num_items
        feedback_msg = RetrieveItems.Feedback()
        result = RetrieveItems.Result()

        index = 0

        #initialize arm position
        req = MoveToCell.Request()
        req.box_index = index
        future = self.move_to_cell_client.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        time.sleep(2.0) # wait for initialization completion

        items_so_far = 0

        # check for cancellation request
        check_cancel(self, goal_handle)
        
        while (items_so_far < num_items):

            if index < 9: index +=1 # index initialized as zero, add one to move to the first box and so on
            else: # if index = 9 all boxes searched and not enough objects found so cancel
                self.get_logger().info("All cells searched, not enough objects found.")
                req = ServoOff.Request()
                result = self.servo_off_client.call_async(req)
                goal_handle.canceled()
                result.success = False
                result.message = 'Goal cancelled.'
                return result
            
            #ensure gripper is open and initialize item_grasped as false
            req = SetGripper.Request()
            req.state = 'open'
            future = self.set_gripper_client.call_async(req)
            rclpy.spin_until_future_complete(self, future)
            req = MoveGraspedToDeposit.Request()
            req.item_grasped = False

            # check for cancellation request
            check_cancel(self, goal_handle)

            feedback_msg.state = 'searching'
            feedback_msg.items_collected = items_so_far
            feedback_msg.current_box = index
            goal_handle.publish_feedback(feedback_msg)

            #move to index cell
            req = MoveToCell.Request()
            req.box_index = index
            future = self.move_to_cell_client.call_async(req)
            rclpy.spin_until_future_complete(self, future)
            time.sleep(2.0) # wait untill you're at the cell

            # check for cancellation request
            check_cancel(self, goal_handle)
            
            #attempt to grasp object
            feedback_msg.state = 'grabbing'
            goal_handle.publish_feedback(feedback_msg)
            req = SetGripper.Request()
            req.state = 'close'
            future = self.set_gripper_client.call_async(req)
            rclpy.spin_until_future_complete(self, future)
            time.sleep(2.0) # wait until the gripper has closed to move on

            #check gripper position to see if it has closed all the way
            req = GetGripperPosition.Request()
            req.pose1 = 800 #initialize position value
            future = self.get_gripper_pos_client.call_async(req)
            rclpy.spin_until_future_complete(self, future)
            resp = future.result()
            
            if resp.position <= 625: # not fully closed -> object has been grasped!
                # check for cancellation request
                check_cancel(self, goal_handle)
                
                # update item count and move grasped item to dropoff location
                items_so_far += 1
                feedback_msg.state = 'dropping off object'
                goal_handle.publish_feedback(feedback_msg)
                req = MoveGraspedToDeposit.Request()
                req.item_grasped = True
                future = self.move_grasped_to_deposit_client.call_async(req)
                rclpy.spin_until_future_complete(self, future)
                req = SetGripper.Request()
                time.sleep(1.0) #wait until dropoff location has been reached

                # check for cancellation request
                check_cancel(self, goal_handle)
                '''
                # release object
                req.state = 'open'
                future = self.set_gripper_client.call_async(req)
                rclpy.spin_until_future_complete(self, future)
                time.sleep(1.0) # wait until gripper has released object
                '''
            feedback_msg.items_collected = items_so_far
            goal_handle.publish_feedback(feedback_msg)


            # check for cancellation request
            check_cancel(self, goal_handle)


        goal_handle.succeed()
        result.success = True
        return result


def main(args=None):
    rclpy.init(args=args)
    node = RetrieveItemsActionServer()

    # MultiThreadedExecutor allows goal, cancel, and execute callbacks to run
    # concurrently — required when the execute_callback blocks or uses await.
    executor = MultiThreadedExecutor()
    executor.add_node(node)

    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()



# check for cancellation request
def check_cancel(self, goal_handle):
    if goal_handle.is_cancel_requested:
            req = ServoOff.Request()
            result = self.servo_off_client.call_async(req)
            goal_handle.canceled()
            result.success = False
            result.message = 'Goal cancelled.'
            return result

"""
# ================= COPY/PASTE BELOW =================
gripper_closed_count = 700
gripper_open_count   = 332

POSITIONS = {
    0: [332, 500, 500, 500, 500, 500],
    1: [332, 499, 799, 139, 528, 631],
    2: [332, 498, 852, 158, 528, 510],
    3: [332, 498, 818, 163, 542, 386],
    4: [332, 498, 739, 190, 593, 610],
    5: [332, 498, 767, 170, 565, 507],
    6: [332, 498, 768, 204, 590, 421],
    7: [332, 498, 704, 256, 661, 586],
    8: [332, 498, 736, 261, 651, 510],
    9: [332, 499, 704, 261, 660, 436],
}

POSITION_DROP = [700, 498, 864, 264, 561, 145]
# ================== COPY/PASTE ABOVE =================
"""
